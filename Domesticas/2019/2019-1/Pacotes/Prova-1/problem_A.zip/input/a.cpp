#include <bits/stdc++.h>

using namespace std;

int main(){
	
	int n, m; cin >> n >> m;
	cout << "M: " << m << endl;
	for(int i = 0; i < m; i++){
		int x, y, z; cin >> x >> y >> z;
		x--; y--;
		if(z > 100000){
			cout << z << endl;
		} else if(x == n or y == n){
			cout << "uahsduashd" << endl;
		}
	}
	
	return 0;
}
